#ifndef WIFI
#define WIFI

void wifi(void);

#endif