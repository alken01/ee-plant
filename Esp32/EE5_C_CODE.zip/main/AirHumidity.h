#ifndef airHumidity
#define airHumidity


void start_humidity(void* arg);
/* start the humidity sensor*/

void stop_humidity(void* arg);
/*stop and free the humidity sensor*/



#endif
