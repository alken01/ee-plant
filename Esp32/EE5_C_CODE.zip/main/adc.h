#ifndef ADC
#define ADC

void start_adc(void* arg);
//void stop_adc(void* arg);


#endif

