#ifndef HTTPS
#define HTTPS

void https_write_with_url(void* arg);
void https_read_with_url(void* arg);

#endif

