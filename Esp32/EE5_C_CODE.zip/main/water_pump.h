#ifndef WATER_PUMP
#define WATER_PUMP

void water_for_5s(void);


#endif